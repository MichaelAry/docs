#include "OperationsWithArrays.h"

int OperationsWithArrays::initNumber(int left, int right){ 
}