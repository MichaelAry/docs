#include <iostream>
#include <list>
int main(){
    int x;
    std::cout<<"введите, сколько грибов вы собрали:"<<std::endl;
    std::cin>>x;
    if (x==0){std::cout<<"вы не собрали грибов"<<std::endl;}
    else if (x<0){std::cout<<"грибы собрали вас"<<std::endl;}
    else if ((x>=11)&&(x<=14)){std::cout<<"вы собрали "<<x<<" грибов"<<std::endl;}
    else if (x%10==1){std::cout<<"вы собрали "<< x <<" гриб"<<std::endl;}
    else if ((x%10 >=5)&&(x%10 <=9)||(x%10 ==0)){std::cout<<"вы собрали "<< x << " грибов"<<std::endl;}
    else if ((x%10>=2)&&(x%10<=4)){std::cout<<"вы собрали "<< x << " гриба"<<std::endl;}
}