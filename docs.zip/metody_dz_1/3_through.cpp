#include <iostream>
#include <cmath>
#include <math.h>

float al;//угол броска
float v0;//начальная скорость
float p;//высота цели
float r;//расстояние до цели
float h;//высота платформы
float t;//время фул полёта
float hk;//высота полёта снаряд в момент поражения цели
float hm;//максимальная высота подлёта тела
float t1;//время от начала до точки максимальной высоты
int directionDefiner=0; //некоторая переменная, которую будем использовать для определения направления полёта и вероятности попадания

int main(){
  std::cout<<"введите начальный угол(градусы) ";std::cin>>al;std::cout<<std::endl; 
  std::cout<<"введите начальную скорость(м/с) ";std::cin>>v0;std::cout<<std::endl; 
  std::cout<<"введите высоту цели(м) ";std::cin>>p;std::cout<<std::endl;
  std::cout<<"введите расстояние до цели(м) ";std::cin>>r;std::cout<<std::endl; 
  std::cout<<"введите высоту платформы(м) ";std::cin>>h;std::cout<<std::endl; 

  if (((r==0)&&(h==0))||((r==0)&&(h<0)&&(p+h>0))){std::cout<<"снаряд уже в цели";std::cout<<std::endl;return 1;}
  if ((al==0)||(v0==0)){std::cout<<"снаряд не попадёт в цель";std::cout<<std::endl;return 1;}

  if (v0<0){directionDefiner++;v0=v0*(-1);}
  if (al<0){directionDefiner++;al0=al0*(-1);}
  if (r<0){directionDefiner++;r=r*(-1);}
  if (directionDefiner%2!=0){std::cout<<"снаряд не попадёт в цель";std::cout<<std::endl;return 1;}

  t=r/(v0*cos(al*M_PIl/180));
  hm=v0*v0*sin(al*M_PIl/180)*sin(al*M_PIl/180)/(2*9.8);  if (h>=hm){std::cout<<"снаряд не попадёт в цель";std::cout<<std::endl; return 1;}
  t1=v0*sin(al*M_PIl/180)/9.8;
  hk=hm-9.8*(t-t1)*(t-t1)/2;

  if (t==t1){hk=hm}   
  if (t<t1){hk=v0*cos(al*M_PIl/180)-9.8*t*t/2;}
  if ((hk>h)&&(hk<=h+p)){std::cout<<"снаряд попадёт в цель";}
  else {std::cout<<"снаряд не попадёт в цель";}

return 0;
}