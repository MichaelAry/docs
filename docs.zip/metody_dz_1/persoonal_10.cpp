#include <iostream>
#include <cstring>
using namespace std;
string ad{""};
string breaker{""};
string multiple1(int func_p_in){//добавляет десятки при счете от 50 до 80
    ad="";
    for (int i=0;i<func_p_in/10-5;i++){
        ad+="X";}
    return ad;
}
string multiple1l(int func_p_in){//добавляет десятки при счете от 10 до 30
    ad="";
    for (int i=0;i<func_p_in/10;i++){
        ad+="X";
    }
    return ad;
}
string multiple2(int func_p_in){//доюавляет единицы
    ad="";
    switch(func_p_in%10){
        case 1: ad=ad+"I";
        break;
        case 2: ad=ad+"II";
        break;
        case 3: ad=ad+"III";
        break;
        case 4: ad=ad+"IV";
        break;
        case 5: ad=ad+"V";
        break;
        case 6: ad=ad+"VI";
        break;
        case 7: ad=ad+"VII";
        break;
        case 8: ad=ad+"VIII";
        break;
        case 9: ad=ad+"IX";
    }
    return ad;
}
int main(){
    int p_in;
    string rim{""};
    do{   
        rim="";
        ad="";
        cin>>p_in; cout<<endl;
        if (p_in/10==5){
            rim=rim+"L";
            if (p_in%10!=0){
                multiple2(p_in);
                rim=rim+ad;}
        }
        else if ((p_in/10>5)&&(p_in/10<=8)){
            multiple1(p_in);
            rim="L"+ad;
            multiple2(p_in);
            rim=rim+ad;   
        } 
        else if ((p_in/10<5)&&(p_in/10>=1)){
            if (p_in/10==1){rim=rim+"X";}
            else if (p_in/10==2){rim=rim+"XX";}
            else if (p_in/10==3){rim=rim+"XXX";}
            else if (p_in/10==4){rim=rim+"XL";}
            multiple2(p_in);
            rim=rim+ad;
        }
        else if (p_in/10==9){
            rim="XC";
            multiple2(p_in);
            rim=rim+ad;
        }
        else if (p_in/10==0){
            multiple2(p_in);
            rim=rim+ad;
        }
        cout<<rim<<endl;
        cout<<"continue?"<<endl;
        cin>>breaker;
    }
        while ((breaker!="done")&&(breaker!="no"));
    return 0;
}