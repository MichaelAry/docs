#include <iostream>

int workChecker; //создаём, чтобы иметь возможность стопнуть прогу из левой функции, меняя в ней глобальное значение и проверяя в основной


int checkExistance(float a, float b, float c,int u){
    if ((a+b>c)&&(a+c>b)&&(b+c>a)){std::cout<<"такой треугольник существует"<<std::endl;}
    else {std::cout<<"такого треугольника не существует";workChecker=1;}
    return 0;
}

int sideEquality(float a, float b, float c){
    if ((a==b)&&(b==c)){std::cout<<"треугольник равносторонний"<<std::endl;}
    else if ((a==b)||(a==c)||(b==c)){std::cout<<"треугольник равнобедренный"<<std::endl;}
    else {std::cout<<"треугольник разносторонний"<<std::endl;}
    return 0;
}

int angleID (float a, float b, float c){
    if((a*a+b*b-c*c)/2*a*b>0){std::cout<<"треугольник остроугольный"<<std::endl;}
    else if((b*b+c*c-a*a)/2*c*b>0){std::cout<<"треугольник остроугольный"<<std::endl;}
    else if((a*a+c*c-b*b)/2*a*c>0){std::cout<<"треугольник остроугольный"<<std::endl;}
    else if ((a*a+b*b-c*c)/2*a*b==0){std::cout<<"треугольник прямоугольный"<<std::endl;}
    else if ((a*a+c*c-b*b)/2*a*c==0){std::cout<<"треугольник прямоугольный"<<std::endl;}
    else if ((c*c+b*b-a*a)/2*c*b==0){std::cout<<"треугольник прямоугольный"<<std::endl;}
    else {std::cout<<"треугольник тупоугольный"<<std::endl;}
    return 0;
}

 int main(){
    float am, bm,cm;
    int u;
    std::cin>>am>>bm>>cm;std::cout<<std::endl;
    if ((am<=0)||(bm<=0)||(cm<=0)){std::cout<<"неправильный ввод"<<std::endl;return 1;}
    checkExistance(am,bm,cm,u);
    if (workChecker==1){return (1);}
    sideEquality(am,bm,cm);
    angleID(am,bm,cm);
    return 0;
 }