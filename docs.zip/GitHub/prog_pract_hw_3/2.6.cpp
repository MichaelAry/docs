#include <iostream> 

int main() {
    std::cout<<"jebgshbfvs";

    return 0; 
}