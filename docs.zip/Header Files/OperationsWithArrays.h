#pragma once

namespace OperationsWithArrays{
    const int right = 5;
    int initNumber(int left, int right);
    void inputArray( int  integer[], int n);
    void outputArray(int a[], int n);
    void reverse(int a[], int n);
    void swap(int& a, int& b);
}