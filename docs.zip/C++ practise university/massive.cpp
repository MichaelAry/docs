#include <iostream>

int main (){
    int integers[10]={0}; //задаёт всем значениям массива 0, вместо базового мусора
    int integers2[5]={1,2,3,4,5};
    for(int i=0;i<5;i++){
            std::cout<<integers2[i]<<std::endl;
            int j=1;
            j=i++ +j;
           // std::cout<<i[integers2]<<std::endl;
    }
    return 0;
}