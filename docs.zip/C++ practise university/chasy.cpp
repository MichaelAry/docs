#include <iostream>
int main() {
    int h,m,s;
    std::cin>>h;
    std::cout<<std::endl;
    std::cin>>m;
    std::cout<<std::endl;
    std::cin>>s;
    if (h>23){h%24;}
    h=h*60*60;
    if (h>86400){h-=86400;}
    if (h>43200){h-=43200;}
    std::cout<<std::endl;
    int tim=h+m*60+s;
    float ugol=360./(43200./tim);
    std::cout<<ugol;
    std::cout<<std::endl;
}
