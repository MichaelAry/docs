#include <iostream>
using namespace std;
int main (){  
    int x;
    int y;
    float z;
    cin>>x;
    cout<<endl;
    cin>>x;
    z=x*x*x-2.5*x*y+1.78*x*x-2.5*y+1;
    cout<<z<<endl;
    }
