#include <iostream>
#include <string>

enum Day{
    None,// создаётся, чтоюы значением None закрыть онль
    Monday=1,//либо сходу задаём начальное значение 
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday,
    Sunday
};

void getMondayChild(Day day); //prototype

int main(){
    int day;

    std::cout<<"Enter day "<<std::endl;
    std::cin>>day;
    getMondayChild((Day)day);
    return 0;
}

void getMondayChild(Day day){
    switch(day){
        case Day::Monday: std::cout<<"Monday's child is fait of face"<<std::endl;
        break;
        case Day::Tuesday: std::cout<<"Monday's child is full of grace"<<std::endl;
        break;
        case Day::Wednesday: std::cout<<"Monday's child is full of moe"<<std::endl;
        break;
        case Day::Thursday: std::cout<<"Monday's child is far to go"<<std::endl;
        break;
        case Day::Friday: std::cout<<"Monday's child is full of moe"<<std::endl;
        break;
        case Day::Saturday: std::cout<<"Monday's child is hard for a living"<<std::endl;
        break;
        case Day::Sunday: std::cout<<"Monday's child is full of moe"<<std::endl;
        break;
        default:std::cout<<"Nah"<<std::endl;
    }
}