#include <iostream>

int main()
{
  std::cout << "Hello, user!";
  return 0; // Возвратим ОС "код успеха".
}