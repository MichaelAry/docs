#include <iostream>
#include <cmath>

int hara (int har){
    int sum{0}, sum2{0};
    int x{0},y{0};
    int lg= log10(har)+1;
    for (int i=1; i<=lg; i++){
        sum=(har%(int)pow(10,i))/pow(10,i-1);
        if (sum>=x){x=sum; y=i;}
    }
    for (int j=0;j<=lg;j++){
        sum2+=(har%(int)pow(10,j))/(int)pow(10,j-1)*pow(-1, y+j);
    }
    return sum2;
}

int main(){
    int har,sum{0};
    std::cin>>har; std::cout<<std::endl;
    std::cout<<hara(har);
    return 0;
}