#include <iostream>


int main (){
    int x=10;
    int counter=0;
/*    std::cout<<"i++ ";
    for (int i=0; i<200;i++){
 //   std::cout<<i<<" ";
    for (int j=0; j<5;j++){
 //   std::cout<<j<<" ";
    counter++;
    }
    }//всегда сразу считается внутренний цикл
    std::cout<<counter;
    std::cout<<std::endl;

    std::cout<<"++i ";
    for (int i=0; i<x;++i){
    std::cout<<i<<" ";}
    std::cout<<std::endl;

    std::cout<<"i-- ";
    for (int i=x;i>0;i--){
    std::cout<<i<<" ";}
    std::cout<<std::endl;

    std::cout<<"--i ";
    for (int i=x;i>0;--i){
    std::cout<<i<<" ";}
    std::cout<<std::endl;
*/
    for (;;){x++;std::cout<<x;}
    return 0;
}