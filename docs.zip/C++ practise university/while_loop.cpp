#include <iostream>
#include <string>

/*int main(){
    int day{0};

    while(true){
        std::cout<<"Enter day "; std::cin>>day;std::cout<<std::endl;
        if (day>=1 && day<=7){
            break;
        }
    }
    std::cout<<"all"<<std::endl;
    return 0;
}*/




/*
do{
    std::cout<<"Enter day "; std::cin>>day;std::cout<<std::endl;
    }
    while(!(day>=1 && day<=7)) иная запись, где цикл сначала делает, а потом проверяет для продолжения следующего круга
*/

enum Day{
    None,// создаётся, чтоюы значением None закрыть онль
    Monday=1,//либо сходу задаём начальное значение 
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday,
    Sunday
};

void getMondayChild(Day day);
int getValue(int start, int end);

int main(){
    int day{getValue(1,7)};
    void getMondayChild(Day day);
    return 0;


}

int getValue(int start, int end){
    int value{0};
    while(true){
        std::cout<<"Enter day "; std::cin>>value;std::cout<<std::endl;
        if (value>=start && value<=end){
            break;
        }
    return value;
    }

void getMondayChild(Day day){
    switch(day){
        case Day::Monday: std::cout<<"Monday's child is fait of face"<<std::endl;
        break;
        case Day::Tuesday: std::cout<<"Monday's child is full of grace"<<std::endl;
        break;
        case Day::Wednesday: std::cout<<"Monday's child is full of moe"<<std::endl;
        break;
        case Day::Thursday: std::cout<<"Monday's child is far to go"<<std::endl;
        break;
        case Day::Friday: std::cout<<"Monday's child is full of moe"<<std::endl;
        break;
        case Day::Saturday: std::cout<<"Monday's child is hard for a living"<<std::endl;
        break;
        case Day::Sunday: std::cout<<"Monday's child is full of moe"<<std::endl;
        break;
        default:std::cout<<"Nah"<<std::endl;
    }
}