#include <iostream>
int main() {
    int x;
    int y;
    int s;
    std::cin>>x;
    std::cout<<std::endl;
    std::cin>>y;
    std::cout<<std::endl;
    std::cin>>s;
    std::cout<<std::endl;
    std::cout<<s/(x+y);
    std::cout<<std::endl;
}