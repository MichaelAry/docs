#include <iostream>

int doSomething(bool b1, bool b2, int i);
void test_doSomething();

int main()
{
	test_doSomething();
}

int doSomething(bool b1, bool b2, int i)
{
	// TODO Implement the method.
}

void test_doSomething()
{
	std::cout << (doSomething(true, true, 0) == -1 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, 1) == 1 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, 2) == 8 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, 3) == 7 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, 4) == 6 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, 5) == 5 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, 6) == 4 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, 7) == 3 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, 8) == 2 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, 9) == 1 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, 10) == 10 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, -1) == -1 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, -2) == 3 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, -3) == 2 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, -4) == 1 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, -5) == 0 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, -6) == -1 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, -7) == -2 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, -8) == -3 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, -9) == -4 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, true, -10) == -10 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, 0) == -1 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, 1) == 1 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, 2) == 12 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, 3) == 13 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, 4) == 14 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, 5) == 15 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, 6) == 16 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, 7) == 17 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, 8) == 18 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, 9) == 19 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, 10) == 10 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, -1) == -1 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, -2) == 7 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, -3) == 8 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, -4) == 9 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, -5) == 10 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, -6) == 11 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, -7) == 12 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, -8) == 13 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, -9) == 14 ? "true" : "false") << std::endl;
	std::cout << (doSomething(true, false, -10) == -10 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, 0) == 1 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, 1) == 11 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, 2) == 12 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, 3) == 13 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, 4) == 14 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, 5) == 5 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, 6) == 6 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, 7) == 7 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, 8) == 8 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, 9) == 9 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, 10) == 11 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, -1) == 9 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, -2) == 8 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, -3) == 7 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, -4) == 6 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, -5) == -5 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, -6) == -6 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, -7) == -7 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, -8) == -8 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, -9) == -9 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, true, -10) == -9 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, 0) == -1 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, 1) == -9 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, 2) == -8 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, 3) == -7 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, 4) == -6 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, 5) == 5 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, 6) == 6 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, 7) == 7 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, 8) == 8 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, 9) == 9 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, 10) == 9 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, -1) == -11 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, -2) == -12 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, -3) == -13 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, -4) == -14 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, -5) == -5 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, -6) == -6 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, -7) == -7 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, -8) == -8 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, -9) == -9 ? "true" : "false") << std::endl;
	std::cout << (doSomething(false, false, -1) == -11 ? "true" : "false") << std::endl;
}