#include <iostream>
#include <cassert>

using namespace std;

int doSomething(bool b1, bool b2, int i);
void test_doSomething();

int main()
{
	test_doSomething();
}

int doSomething(bool b1, bool b2, int i)
{
	// TODO Implement the method.
}

void test_doSomething()
{
    assert(doSomething(true, true, 0) == 0);
    assert(doSomething(true, true, 1) == -2);
    assert(doSomething(true, true, 2) == -4);
    assert(doSomething(true, true, 3) == -6);
    assert(doSomething(true, true, 4) == -8);
    assert(doSomething(true, true, 5) == -10);
    assert(doSomething(true, true, 6) == -2);
    assert(doSomething(true, true, 7) == -4);
    assert(doSomething(true, true, 8) == -6);
    assert(doSomething(true, true, 9) == -8);
    assert(doSomething(true, true, 10) == -10);
    assert(doSomething(true, true, -1) == 2);
    assert(doSomething(true, true, -2) == 4);
    assert(doSomething(true, true, -3) == 6);
    assert(doSomething(true, true, -4) == 8);
    assert(doSomething(true, true, -5) == 20);
    assert(doSomething(true, true, -6) == 22);
    assert(doSomething(true, true, -7) == 24);
    assert(doSomething(true, true, -8) == 26);
    assert(doSomething(true, true, -9) == 28);
    assert(doSomething(true, true, -10) == 30);
    assert(doSomething(true, false, 0) == 0);
    assert(doSomething(true, false, 1) == 1);
    assert(doSomething(true, false, 2) == 4);
    assert(doSomething(true, false, 3) == 9);
    assert(doSomething(true, false, 4) == 16);
    assert(doSomething(true, false, 5) == 25);
    assert(doSomething(true, false, 6) == 216);
    assert(doSomething(true, false, 7) == 343);
    assert(doSomething(true, false, 8) == 512);
    assert(doSomething(true, false, 9) == 729);
    assert(doSomething(true, false, 10) == 1000);
    assert(doSomething(true, false, -1) == 1);
    assert(doSomething(true, false, -2) == 4);
    assert(doSomething(true, false, -3) == 9);
    assert(doSomething(true, false, -4) == 16);
    assert(doSomething(true, false, -5) == -125);
    assert(doSomething(true, false, -6) == -216);
    assert(doSomething(true, false, -7) == -343);
    assert(doSomething(true, false, -8) == -512);
    assert(doSomething(true, false, -9) == -729);
    assert(doSomething(true, false, -10) == -1000);
    assert(doSomething(false, true, 0) == 0);
    assert(doSomething(false, true, 1) == 1);
    assert(doSomething(false, true, 2) == 2);
    assert(doSomething(false, true, 3) == 3);
    assert(doSomething(false, true, 4) == 4);
    assert(doSomething(false, true, 5) == 5);
    assert(doSomething(false, true, 6) == 6);
    assert(doSomething(false, true, 7) == 7);
    assert(doSomething(false, true, 8) == -8);
    assert(doSomething(false, true, 9) == -9);
    assert(doSomething(false, true, 10) == -10);
    assert(doSomething(false, true, -1) == -1);
    assert(doSomething(false, true, -2) == -2);
    assert(doSomething(false, true, -3) == -3);
    assert(doSomething(false, true, -4) == -40);
    assert(doSomething(false, true, -5) == -50);
    assert(doSomething(false, true, -6) == -60);
    assert(doSomething(false, true, -7) == -70);
    assert(doSomething(false, true, -8) == -8);
    assert(doSomething(false, true, -9) == -9);
    assert(doSomething(false, true, -10) == 10);
    assert(doSomething(false, false, 0) == 0);
    assert(doSomething(false, false, 1) == -100);
    assert(doSomething(false, false, 2) == -200);
    assert(doSomething(false, false, 3) == -300);
    assert(doSomething(false, false, 4) == -400);
    assert(doSomething(false, false, 5) == 5);
    assert(doSomething(false, false, 6) == 6);
    assert(doSomething(false, false, 7) == 7);
    assert(doSomething(false, false, 8) == -8);
    assert(doSomething(false, false, 9) == -9);
    assert(doSomething(false, false, 10) == -10);
    assert(doSomething(false, false, -1) == 100);
    assert(doSomething(false, false, -2) == 200);
    assert(doSomething(false, false, -3) == 300);
    assert(doSomething(false, false, -4) == -4);
    assert(doSomething(false, false, -5) == -5);
    assert(doSomething(false, false, -6) == -6);
    assert(doSomething(false, false, -7) == -7);
    assert(doSomething(false, false, -8) == -8);
    assert(doSomething(false, false, -9) == -9);
    assert(doSomething(false, false, -10) == 10);

    std::cout << "All tests passed!" << std::endl;
}
