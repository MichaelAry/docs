#include <iostream>
#include <cassert>

using namespace std;

int doSomething(bool b, int i);
void test_doSomething();

int main()
{
	test_doSomething();
}

int doSomething(bool b, int i)
{
	// TODO Implement the method.
}

void test_doSomething()
{
    // Tests for b = true
    assert(doSomething(true, 0) == 10);
    assert(doSomething(true, 1) == -4);
    assert(doSomething(true, 2) == -3);
    assert(doSomething(true, 3) == -2);
    assert(doSomething(true, 4) == -4);
    assert(doSomething(true, 5) == -5);
    assert(doSomething(true, 6) == -6);
    assert(doSomething(true, 7) == -7);
    assert(doSomething(true, 8) == -8);
    assert(doSomething(true, 9) == -9);
    assert(doSomething(true, 10) == -10);
    assert(doSomething(true, -1) == 4);
    assert(doSomething(true, -2) == 3);
    assert(doSomething(true, -3) == 2);
    assert(doSomething(true, -4) == 1);
    assert(doSomething(true, -5) == -5);
    assert(doSomething(true, -6) == -6);
    assert(doSomething(true, -7) == -7);
    assert(doSomething(true, -8) == -8);
    assert(doSomething(true, -9) == -4);
    assert(doSomething(true, -10) == -5);

    // Tests for b = false
    assert(doSomething(false, 0) == 10);
    assert(doSomething(false, 1) == 9);
    assert(doSomething(false, 2) == 8);
    assert(doSomething(false, 3) == 7);
    assert(doSomething(false, 4) == 6);
    assert(doSomething(false, 5) == 5);
    assert(doSomething(false, 6) == -6);
    assert(doSomething(false, 7) == -7);
    assert(doSomething(false, 8) == -8);
    assert(doSomething(false, 9) == -9);
    assert(doSomething(false, 10) == -10);
    assert(doSomething(false, -1) == 11);
    assert(doSomething(false, -2) == 12);
    assert(doSomething(false, -3) == 13);
    assert(doSomething(false, -4) == 14);
    assert(doSomething(false, -5) == 5);
    assert(doSomething(false, -6) == 6);
    assert(doSomething(false, -7) == 7);
    assert(doSomething(false, -8) == 8);
    assert(doSomething(false, -9) == 9);
    assert(doSomething(false, -10) == 10);

    std::cout << "All tests passed!" << std::endl;
}

