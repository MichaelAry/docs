#include <iostream>

using namespace std;

int doSomething(int i);
void test_doSomething();

int main()
{
	test_doSomething();
}

int doSomething(int i)
{
	// TODO Implement the method.
}

void test_doSomething()
{
	cout << (doSomething(0) == 0 ? "true" : "false") << endl;
	cout << (doSomething(1) == 1 ? "true" : "false") << endl;
	cout << (doSomething(2) == 2 ? "true" : "false") << endl;
	cout << (doSomething(3) == 3 ? "true" : "false") << endl;
	cout << (doSomething(4) == 4 ? "true" : "false") << endl;
	cout << (doSomething(5) == 5 ? "true" : "false") << endl;
	cout << (doSomething(6) == 6 ? "true" : "false") << endl;
	cout << (doSomething(7) == 7 ? "true" : "false") << endl;
	cout << (doSomething(8) == 8 ? "true" : "false") << endl;
	cout << (doSomething(9) == 9 ? "true" : "false") << endl;
	cout << (doSomething(10) == 10 ? "true" : "false") << endl;
	cout << (doSomething(-1) == 0 ? "true" : "false") << endl;
	cout << (doSomething(-2) == 0 ? "true" : "false") << endl;
	cout << (doSomething(-3) == 0 ? "true" : "false") << endl;
	cout << (doSomething(-4) == 0 ? "true" : "false") << endl;
	cout << (doSomething(-5) == 0 ? "true" : "false") << endl;
	cout << (doSomething(-6) == 0 ? "true" : "false") << endl;
	cout << (doSomething(-7) == 0 ? "true" : "false") << endl;
	cout << (doSomething(-8) == 0 ? "true" : "false") << endl;
	cout << (doSomething(-9) == 0 ? "true" : "false") << endl;
	cout << (doSomething(-1) == 0 ? "true" : "false") << endl;
}


