#include <iostream>
#include <cassert>

int doSomething(bool b1, bool b2, int i);

void test_doSomething();

int main()
{
	test_doSomething();
}

int doSomething(bool b1, bool b2, int i)
{
	// TODO Implement the method.
}

void test_doSomething()
{
	// (true, true, i)
	assert(doSomething(true, true, 0) == 1);
	assert(doSomething(true, true, 1) == 1);
	assert(doSomething(true, true, 2) == 2);
	assert(doSomething(true, true, 3) == 3);
	assert(doSomething(true, true, 4) == 8);
	assert(doSomething(true, true, 5) == 10);
	assert(doSomething(true, true, 6) == 12);
	assert(doSomething(true, true, 7) == 14);
	assert(doSomething(true, true, 8) == 8);
	assert(doSomething(true, true, 9) == 9);
	assert(doSomething(true, true, 10) == 10);
	assert(doSomething(true, true, -1) == -1);
	assert(doSomething(true, true, -2) == -2);
	assert(doSomething(true, true, -3) == -3);
	assert(doSomething(true, true, -4) == -4);
	assert(doSomething(true, true, -5) == -15);
	assert(doSomething(true, true, -6) == -18);
	assert(doSomething(true, true, -7) == -21);
	assert(doSomething(true, true, -8) == -24);
	assert(doSomething(true, true, -9) == -9);
	assert(doSomething(true, true, -10) == -10);

	// (true, false, i)
	assert(doSomething(true, false, 0) == -1);
	assert(doSomething(true, false, 1) == 1);
	assert(doSomething(true, false, 2) == 2);
	assert(doSomething(true, false, 3) == 3);
	assert(doSomething(true, false, 4) == 2);
	assert(doSomething(true, false, 5) == 0);
	assert(doSomething(true, false, 6) == -2);
	assert(doSomething(true, false, 7) == -4);
	assert(doSomething(true, false, 8) == 8);
	assert(doSomething(true, false, 9) == 9);
	assert(doSomething(true, false, 10) == 10);
	assert(doSomething(true, false, -1) == -1);
	assert(doSomething(true, false, -2) == -2);
	assert(doSomething(true, false, -3) == 1);
	assert(doSomething(true, false, -4) == -2);
	assert(doSomething(true, false, -5) == -5);
	assert(doSomething(true, false, -6) == -8);
	assert(doSomething(true, false, -7) == -7);
	assert(doSomething(true, false, -8) == -8);
	assert(doSomething(true, false, -9) == -9);
	assert(doSomething(true, false, -10) == -10);

	// (false, true, i)
	assert(doSomething(false, true, 0) == 1);
	assert(doSomething(false, true, 1) == 0);
	assert(doSomething(false, true, 2) == -4);
	assert(doSomething(false, true, 3) == -18);
	assert(doSomething(false, true, 4) == -48);
	assert(doSomething(false, true, 5) == 5);
	assert(doSomething(false, true, 6) == 6);
	assert(doSomething(false, true, 7) == 7);
	assert(doSomething(false, true, 8) == -56);
	assert(doSomething(false, true, 9) == -72);
	assert(doSomething(false, true, 10) == -90);
	assert(doSomething(false, true, -1) == 2);
	assert(doSomething(false, true, -2) == 12);
	assert(doSomething(false, true, -3) == 36);
	assert(doSomething(false, true, -4) == -4);
	assert(doSomething(false, true, -5) == -5);
	assert(doSomething(false, true, -6) == -6);
	assert(doSomething(false, true, -7) == -7);
	assert(doSomething(false, true, -8) == -8);
	assert(doSomething(false, true, -9) == -90);
	assert(doSomething(false, true, -10) == -110);

	// (false, false, i)
	assert(doSomething(false, false, 0) == 1);
	assert(doSomething(false, false, 1) == 0);
	assert(doSomething(false, false, 2) == 4);
	assert(doSomething(false, false, 3) == 3);
	assert(doSomething(false, false, 4) == 4);
	assert(doSomething(false, false, 5) == 5);
	assert(doSomething(false, false, 6) == 6);
	assert(doSomething(false, false, 7) == 7);
	assert(doSomething(false, false, 8) == -504);
	assert(doSomething(false, false, 9) == -720);
	assert(doSomething(false, false, 10) == -990);
	assert(doSomething(false, false, -1) == -2);
	assert(doSomething(false, false, -2) == -12);
	assert(doSomething(false, false, -3) == -36);
	assert(doSomething(false, false, -4) == -4);
	assert(doSomething(false, false, -5) == -5);
	assert(doSomething(false, false, -6) == -6);
	assert(doSomething(false, false, -7) == 336);
	assert(doSomething(false, false, -8) == 504);
	assert(doSomething(false, false, -9) == 720);
	assert(doSomething(false, false, -10) == 990);

	std::cout << "All tests passed!" << std::endl;
}
