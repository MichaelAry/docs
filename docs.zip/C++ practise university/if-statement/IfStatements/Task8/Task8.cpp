#include <iostream>
#include <cassert>

int doSomething(bool b, int i);
void test_doSomething();

int main()
{
    test_doSomething();
}

int doSomething(bool b, int i)
{
    // TODO Implement the method.
}

void test_doSomething()
{
    assert(doSomething(true, 0) == false);
    assert(doSomething(true, 1) == true);
    assert(doSomething(true, 2) == true);
    assert(doSomething(true, 3) == true);
    assert(doSomething(true, 4) == false);
    assert(doSomething(true, 5) == false);
    assert(doSomething(true, 6) == false);
    assert(doSomething(true, 7) == true);
    assert(doSomething(true, 8) == true);
    assert(doSomething(true, 9) == true);
    assert(doSomething(true, 10) == true);
    assert(doSomething(true, -1) == true);
    assert(doSomething(true, -2) == true);
    assert(doSomething(true, -3) == true);
    assert(doSomething(true, -4) == false);
    assert(doSomething(true, -5) == false);
    assert(doSomething(true, -6) == false);
    assert(doSomething(true, -7) == true);
    assert(doSomething(true, -8) == true);
    assert(doSomething(true, -9) == true);
    assert(doSomething(true, -10) == true);

    assert(doSomething(false, 0) == false);
    assert(doSomething(false, 1) == true);
    assert(doSomething(false, 2) == true);
    assert(doSomething(false, 3) == false);
    assert(doSomething(false, 4) == false);
    assert(doSomething(false, 5) == false);
    assert(doSomething(false, 6) == false);
    assert(doSomething(false, 7) == true);
    assert(doSomething(false, 8) == true);
    assert(doSomething(false, 9) == true);
    assert(doSomething(false, 10) == true);
    assert(doSomething(false, -1) == true);
    assert(doSomething(false, -2) == true);
    assert(doSomething(false, -3) == false);
    assert(doSomething(false, -4) == false);
    assert(doSomething(false, -5) == false);
    assert(doSomething(false, -6) == false);
    assert(doSomething(false, -7) == true);
    assert(doSomething(false, -8) == true);
    assert(doSomething(false, -9) == true);
    assert(doSomething(false, -10) == true);

    std::cout << "All test cases passed!" << std::endl;
}
