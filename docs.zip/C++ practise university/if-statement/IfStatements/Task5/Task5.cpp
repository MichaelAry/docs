#include <iostream>
#include <cassert>

int doSomething(int i);
int doSomethingRefactoring(int i);

void test_doSomething();
void test_doSomethingRefactoring();

int main()
{
	test_doSomething();
	test_doSomethingRefactoring();
}

int doSomething(int i)
{
	// TODO Implement the method.
}

int doSomethingRefactoring(int i)
{
	// TODO Implement the method.
}

void test_doSomething()
{
	assert(doSomething(0) == 0);
	assert(doSomething(1) == -4);
	assert(doSomething(2) == -3);
	assert(doSomething(3) == -2);
	assert(doSomething(4) == -1);
	assert(doSomething(5) == 0);
	assert(doSomething(6) == 6);
	assert(doSomething(7) == 7);
	assert(doSomething(8) == 8);
	assert(doSomething(9) == 9);
	assert(doSomething(10) == 10);
	assert(doSomething(-1) == 4);
	assert(doSomething(-2) == 3);
	assert(doSomething(-3) == 2);
	assert(doSomething(-4) == 1);
	assert(doSomething(-5) == 0);
	assert(doSomething(-6) == -6);
	assert(doSomething(-7) == -7);
	assert(doSomething(-8) == -8);
	assert(doSomething(-9) == -9);
	assert(doSomething(-10) == -10);

	std::cout << "All test cases passed!" << std::endl;
}

void test_doSomethingRefactoring()
{
	assert(doSomething(0) == 0);
	assert(doSomething(1) == -4);
	assert(doSomething(2) == -3);
	assert(doSomething(3) == -2);
	assert(doSomething(4) == -1);
	assert(doSomething(5) == 0);
	assert(doSomething(6) == 6);
	assert(doSomething(7) == 7);
	assert(doSomething(8) == 8);
	assert(doSomething(9) == 9);
	assert(doSomething(10) == 10);
	assert(doSomething(-1) == 4);
	assert(doSomething(-2) == 3);
	assert(doSomething(-3) == 2);
	assert(doSomething(-4) == 1);
	assert(doSomething(-5) == 0);
	assert(doSomething(-6) == -6);
	assert(doSomething(-7) == -7);
	assert(doSomething(-8) == -8);
	assert(doSomething(-9) == -9);
	assert(doSomething(-10) == -10);

	std::cout << "All test cases passed!" << std::endl;
}

