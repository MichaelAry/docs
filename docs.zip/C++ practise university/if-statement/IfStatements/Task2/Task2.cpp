#include <iostream>
#include <cassert>

int doSomething1(int i);
int doSomething2(int i);

void test_doSomething1();
void test_doSomething2();

int main()
{
	test_doSomething1();
	test_doSomething2();
}

int doSomething1(int i)
{
	// TODO Implement the method.
}

int doSomething2(int i)
{
	// TODO Implement the method.
}

void test_doSomething1()
{
	assert(doSomething1(0) == 0);
	assert(doSomething1(1) == 1);
	assert(doSomething1(2) == 2);
	assert(doSomething1(3) == 3);
	assert(doSomething1(4) == 4);
	assert(doSomething1(5) == 5);
	assert(doSomething1(6) == 6);
	assert(doSomething1(7) == 7);
	assert(doSomething1(8) == 8);
	assert(doSomething1(9) == 9);
	assert(doSomething1(10) == 10);
	assert(doSomething1(-1) == 1);
	assert(doSomething1(-2) == 2);
	assert(doSomething1(-3) == 3);
	assert(doSomething1(-4) == 4);
	assert(doSomething1(-5) == 5);
	assert(doSomething1(-6) == -36);
	assert(doSomething1(-7) == -49);
	assert(doSomething1(-8) == -64);
	assert(doSomething1(-9) == -81);
	assert(doSomething1(-10) == -100);
	std::cout << "All tests passed!" << std::endl;
}

void test_doSomething2()
{
	assert(doSomething2(0) == 0);
	assert(doSomething2(1) == 1);
	assert(doSomething2(2) == 2);
	assert(doSomething2(3) == 3);
	assert(doSomething2(4) == 4);
	assert(doSomething2(5) == 5);
	assert(doSomething2(6) == 6);
	assert(doSomething2(7) == 7);
	assert(doSomething2(8) == 8);
	assert(doSomething2(9) == 9);
	assert(doSomething2(10) == 10);
	assert(doSomething2(-1) == 1);
	assert(doSomething2(-2) == 2);
	assert(doSomething2(-3) == 3);
	assert(doSomething2(-4) == 4);
	assert(doSomething2(-5) == 5);
	assert(doSomething2(-6) == -36);
	assert(doSomething2(-7) == -49);
	assert(doSomething2(-8) == -64);
	assert(doSomething2(-9) == -81);
	assert(doSomething2(-10) == -100);

	std::cout << "All tests passed!" << std::endl;
}

