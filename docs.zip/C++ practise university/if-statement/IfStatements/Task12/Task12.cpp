#include <iostream>
#include <cassert>

using namespace std;

int doSomething(int i);
void test_doSomething();

int main()
{
	test_doSomething();
}

int doSomething(int i)
{
	// TODO Implement the method.
}

void test_doSomething()
{
    assert(doSomething(0) == 0);
    assert(doSomething(1) == 0);
    assert(doSomething(2) == 2);
    assert(doSomething(3) == 6);
    assert(doSomething(4) == 12);
    assert(doSomething(5) == 5);
    assert(doSomething(6) == 6);
    assert(doSomething(7) == 7);
    assert(doSomething(8) == 8);
    assert(doSomething(9) == 9);
    assert(doSomething(10) == -100);
    assert(doSomething(-1) == 2);
    assert(doSomething(-2) == 6);
    assert(doSomething(-3) == 12);
    assert(doSomething(-4) == 20);
    assert(doSomething(-5) == 30);
    assert(doSomething(-6) == -6);
    assert(doSomething(-7) == -7);
    assert(doSomething(-8) == -8);
    assert(doSomething(-9) == 81);
    assert(doSomething(-10) == 100);
    std::cout << "All tests passed!" << std::endl;
}