#include <iostream>
#include <cassert>

int doSomething(bool b, int i);
int doSomethingRefactoring(bool b, int i);

void test_doSomething();
void test_doSomethingRefactoring();

int main()
{
    test_doSomething();
    test_doSomethingRefactoring();
}

int doSomething(bool b, int i)
{
    // TODO Implement the method.
}

int doSomethingRefactoring(bool b, int i)
{
    // TODO Implement the method.
}


void test_doSomething()
{
    // Test cases for b = true
    assert(doSomething(true, 0) == 7);
    assert(doSomething(true, 1) == 6);
    assert(doSomething(true, 2) == 5);
    assert(doSomething(true, 3) == 4);
    assert(doSomething(true, 4) == 3);
    assert(doSomething(true, 5) == 2);
    assert(doSomething(true, 6) == 1);
    assert(doSomething(true, 7) == 7);
    assert(doSomething(true, 8) == 8);
    assert(doSomething(true, 9) == 9);
    assert(doSomething(true, 10) == 10);
    assert(doSomething(true, -1) == 8);
    assert(doSomething(true, -2) == 9);
    assert(doSomething(true, -3) == 10);
    assert(doSomething(true, -4) == 11);
    assert(doSomething(true, -5) == 12);
    assert(doSomething(true, -6) == 13);
    assert(doSomething(true, -7) == -7);
    assert(doSomething(true, -8) == -8);
    assert(doSomething(true, -9) == -9);
    assert(doSomething(true, -10) == -10);

    // Test cases for b = false
    assert(doSomething(false, 0) == 0);
    assert(doSomething(false, 1) == 1);
    assert(doSomething(false, 2) == 2);
    assert(doSomething(false, 3) == 3);
    assert(doSomething(false, 4) == 4);
    assert(doSomething(false, 5) == 10);
    assert(doSomething(false, 6) == 11);
    assert(doSomething(false, 7) == 12);
    assert(doSomething(false, 8) == 13);
    assert(doSomething(false, 9) == 14);
    assert(doSomething(false, 10) == 15);
    assert(doSomething(false, -1) == -1);
    assert(doSomething(false, -2) == -2);
    assert(doSomething(false, -3) == -3);
    assert(doSomething(false, -4) == -4);
    assert(doSomething(false, -5) == 0);
    assert(doSomething(false, -6) == -1);
    assert(doSomething(false, -7) == -2);
    assert(doSomething(false, -8) == -3);
    assert(doSomething(false, -9) == -4);
    assert(doSomething(false, -10) == -5);

    std::cout << "All test cases passed!" << std::endl;
}

void test_doSomethingRefactoring()
{
    // Test cases for b = true
    assert(doSomething(true, 0) == 7);
    assert(doSomething(true, 1) == 6);
    assert(doSomething(true, 2) == 5);
    assert(doSomething(true, 3) == 4);
    assert(doSomething(true, 4) == 3);
    assert(doSomething(true, 5) == 2);
    assert(doSomething(true, 6) == 1);
    assert(doSomething(true, 7) == 7);
    assert(doSomething(true, 8) == 8);
    assert(doSomething(true, 9) == 9);
    assert(doSomething(true, 10) == 10);
    assert(doSomething(true, -1) == 8);
    assert(doSomething(true, -2) == 9);
    assert(doSomething(true, -3) == 10);
    assert(doSomething(true, -4) == 11);
    assert(doSomething(true, -5) == 12);
    assert(doSomething(true, -6) == 13);
    assert(doSomething(true, -7) == -7);
    assert(doSomething(true, -8) == -8);
    assert(doSomething(true, -9) == -9);
    assert(doSomething(true, -10) == -10);

    // Test cases for b = false
    assert(doSomething(false, 0) == 0);
    assert(doSomething(false, 1) == 1);
    assert(doSomething(false, 2) == 2);
    assert(doSomething(false, 3) == 3);
    assert(doSomething(false, 4) == 4);
    assert(doSomething(false, 5) == 10);
    assert(doSomething(false, 6) == 11);
    assert(doSomething(false, 7) == 12);
    assert(doSomething(false, 8) == 13);
    assert(doSomething(false, 9) == 14);
    assert(doSomething(false, 10) == 15);
    assert(doSomething(false, -1) == -1);
    assert(doSomething(false, -2) == -2);
    assert(doSomething(false, -3) == -3);
    assert(doSomething(false, -4) == -4);
    assert(doSomething(false, -5) == 0);
    assert(doSomething(false, -6) == -1);
    assert(doSomething(false, -7) == -2);
    assert(doSomething(false, -8) == -3);
    assert(doSomething(false, -9) == -4);
    assert(doSomething(false, -10) == -5);

    std::cout << "All test cases passed!" << std::endl;
}