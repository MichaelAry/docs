#include <iostream>
#include <cassert>

bool doSomething1(bool b1, bool b2);
bool doSomething2(bool b1, bool b2);

void test_doSomething1();
void test_doSomething2();

int main()
{
    test_doSomething1();
    test_doSomething2();
}

bool doSomething1(bool b1, bool b2)
{
    // TODO Implement the method.
}

bool doSomething2(bool b1, bool b2)
{
    // TODO Implement the method.
}

void test_doSomething1()
{
    assert(doSomething1(true, true) == false);
    assert(doSomething1(false, true) == true);
    assert(doSomething1(true, false) == true);
    assert(doSomething1(false, false) == false);

    std::cout << "All tests passed!" << std::endl;
}

void test_doSomething2()
{
    assert(doSomething2(true, true) == false);
    assert(doSomething2(false, true) == true);
    assert(doSomething2(true, false) == true);
    assert(doSomething2(false, false) == false);
    std::cout << "All tests passed!" << std::endl;
}
