# if Statement in C++

## SYNTAX

<details><summary></summary>

The `if` statement is a control structure in C++ that allows the program to make decisions based on conditions. It executes a block of code only if a specified condition evaluates to `true`. Here's a breakdown of how it works:

![if flowchart](images/if-statements-flowchart.png)

1. **Basic `if` Statement:**
   - Syntax:
     ```cpp
     if (expression) 
     {
         // Code to execute if the expression is true
     }
     ```
   - The condition inside the parentheses is evaluated. If the condition is `true`, the code block inside the braces `{}` is executed.
   - If the condition is `false`, the program skips the block and continues with the next part of the code.

2. **`if-else` Statement:**
   - Syntax:
     ```cpp
     if (expression) 
     {
         // Code to execute if the expression is true
     } 
     else 
     {
         // Code to execute if the expression is false
     }
     ```
   - If the condition is `true`, the first block of code runs. If the condition is `false`, the `else` block runs.
   - This structure allows you to handle two possible outcomes based on the condition.

3. **`if-else if-else` Ladder:**
   - Syntax:
     ```cpp
     if (expression1) 
     {
         // Code to execute if expression1 is true
     } 
     else if (condition2) 
     {
         // Code to execute if expression1 is false and expression2 is true
     } 
     else 
     {
         // Code to execute if both expressions are false
     }
     ```
   - This structure allows the program to check multiple conditions sequentially.
   - The first `if` condition is checked. If `false`, it checks the `else if` conditions. If none of the conditions are `true`, the final `else` block is executed.

4. **Nested `if` Statements:**
   - Syntax:
     ```cpp
     if (expression1) 
     {
         if (expression2) 
         {
             // Code to execute if both expression1 and expression2 are true
         }
     }
     ```
   - In this structure, an `if` statement is placed inside another `if`. The inner condition is checked only if the outer condition is `true`.
   - This allows for more complex decision-making processes where multiple conditions need to be satisfied.

5. **Logical Operators in `if` Conditions:**
   - Conditions can be combined using logical operators like `&&` (AND), `||` (OR), and `!` (NOT).
     - `&&` ensures both conditions must be true.
     - `||` means only one condition needs to be true.
     - `!` negates the condition, reversing its truth value.

### Summary:
- The `if` statement is a fundamental control structure that enables decision-making in C++.
- It evaluates conditions and executes code blocks based on whether those conditions are true or false.
- With `else if`, `else`, nested `if`, and logical operators, you can handle complex decision-making in your programs.

</details>

## EXAMPLES
<details><summary></summary>

### 1. **Basic `if` Statement**

The `if` statement allows us to execute a block of code only if a certain condition is true.

```cpp
#include <iostream>
using namespace std;

int main() 
{
    int age = 18;

    if (age >= 18) 
    {
        cout << "You are eligible to vote." << endl;
    }

    return 0;
}
```

**Explanation:**
- In this code, the condition `age >= 18` checks if the person is 18 or older.
- If the condition is true (as it is in this case), the message "You are eligible to vote." is printed.
- If the condition is false, the code inside the `if` block is skipped.

### 2. **`if-else` Statement**

The `if-else` statement lets us run one block of code if a condition is true, and a different block if the condition is false.

```cpp
#include <iostream>
using namespace std;

int main() 
{
    int age = 16;

    if (age >= 18) 
    {
        cout << "You are eligible to vote." << endl;
    } 
    else 
    {
        cout << "You are not eligible to vote." << endl;
    }

    return 0;
}
```

**Explanation:**
- If `age >= 18` is true, the program prints "You are eligible to vote."
- If it's false (as in this case with `age = 16`), the program prints "You are not eligible to vote."

### 3. **`if-else if-else` Ladder**

The `if-else if-else` ladder is used when there are multiple conditions to check.

```cpp
#include <iostream>
using namespace std;

int main() 
{
    int score = 85;

    if (score >= 90) 
    {
        cout << "Grade: A" << endl;
    } 
    else if (score >= 80) 
    {
        cout << "Grade: B" << endl;
    } 
    else if (score >= 70) 
    {
        cout << "Grade: C" << endl;
    } 
    else 
    {
        cout << "Grade: F" << endl;
    }

    return 0;
}
```

**Explanation:**
- The program evaluates multiple conditions one by one:
  - If the score is 90 or above, it prints "Grade: A".
  - If the score is between 80 and 89, it prints "Grade: B".
  - If the score is between 70 and 79, it prints "Grade: C".
  - Otherwise, it prints "Grade: F".

### 4. **Nested `if` Statements**

`if` statements can be nested inside one another to check multiple conditions.

```cpp
#include <iostream>
using namespace std;

int main() 
{
    int age = 20;
    bool hasId = true;

    if (age >= 18) 
    {
        if (hasId) 
        {
            cout << "You are allowed to enter." << endl;
        } 
        else 
        {
            cout << "You need to show an ID." << endl;
        }
    } 
    else 
    {
        cout << "You are too young to enter." << endl;
    }

    return 0;
}
```

**Explanation:**
- The outer `if` checks if the age is 18 or older.
- If true, the nested `if` checks if the person has an ID.
  - If they have an ID, it prints "You are allowed to enter."
  - If they don't, it prints "You need to show an ID."
- If the person is under 18, it prints "You are too young to enter."

### 5. **Using Logical Operators in `if`**

You can combine conditions using logical operators like `&&` (AND) and `||` (OR).

```cpp
#include <iostream>
using namespace std;

int main() 
{
    int age = 20;
    bool hasId = false;

    if (age >= 18 && hasId) 
    {
        cout << "You are allowed to enter." << endl;
    } 
    else 
    {
        cout << "You cannot enter." << endl;
    }

    return 0;
}
```

**Explanation:**
- The `&&` operator means both conditions must be true for the entire expression to be true.
- In this example, the user must be 18 or older **and** have an ID to be allowed to enter.
- If either condition is false (e.g., `hasId = false`), the program prints "You cannot enter."

### 6. **Ternary Operator as a Shortcut**

The ternary operator `?:` is a compact way to write simple `if-else` conditions.

```cpp
#include <iostream>
using namespace std;

int main() 
{
    int age = 16;
    string result = (age >= 18) ? "You are an adult." : "You are a minor.";

    cout << result << endl;
    return 0;
}
```

**Explanation:**
- This is a shorthand for `if-else`.
- If `age >= 18`, the string "You are an adult." is assigned to `result`.
- Otherwise, "You are a minor." is assigned.

### 7. Nested `if-else` with multiple statements

```cpp
#include <iostream>

int main()
{
    int a = 5, b = 10;

    if (a < b)
    {
        if (a % 2 == 0)
        {
            std::cout << "a is even and less than b." << std::endl;
            a *= 2;
        }
        else
        {
            std::cout << "a is odd and less than b." << std::endl;
            a += 1;
            b -= 2;
        }
    }
    else
    {
        if (b % 2 == 0)
        {
            std::cout << "b is even and greater than or equal to a." << std::endl;
            b /= 2;
        }
        else
        {
            std::cout << "b is odd and greater than or equal to a." << std::endl;
            b *= 2;
            a -= 1;
        }
    }

    std::cout << "Final values - a: " << a << ", b: " << b << std::endl;

    return 0;
}
```

#### Explanation:
- The program initializes two integers `a` and `b`.
- It first checks if `a` is less than `b`. If true, it further checks if `a` is even (`a % 2 == 0`).
    - If `a` is even, it multiplies `a` by 2.
    - If `a` is odd, it increments `a` by 1 and decrements `b` by 2.
- If `a` is not less than `b`, the outer `else` executes. It checks if `b` is even.
    - If `b` is even, it divides `b` by 2.
    - If `b` is odd, it multiplies `b` by 2 and decrements `a` by 1.
- Finally, it prints the updated values of `a` and `b`.

#### Result:
For `a = 5` and `b = 10`, the output will be:
```
a is odd and less than b.
Final values - a: 6, b: 8
```

### 8 `if-else` in a function with multiple statements in each branch

```cpp
#include <iostream>

void checkNumbers(int x, int y)
{
    if (x > y)
    {
        if (x > 0)
        {
            std::cout << "x is positive and greater than y." << std::endl;
            x -= y;
            y += 3;
        }
        else
        {
            std::cout << "x is non-positive but greater than y." << std::endl;
            x += 2;
            y *= 2;
        }
    }
    else
    {
        if (y > 0)
        {
            std::cout << "y is positive and greater than or equal to x." << std::endl;
            y -= x;
            x *= 2;
        }
        else
        {
            std::cout << "y is non-positive and greater than or equal to x." << std::endl;
            x += y;
            y += 2;
        }
    }

    std::cout << "After check: x = " << x << ", y = " << y << std::endl;
}

int main()
{
    checkNumbers(5, 3);
    checkNumbers(-2, 7);

    return 0;
}
```

#### Explanation:
- This code defines a function `checkNumbers` that compares two integers `x` and `y`.
- If `x` is greater than `y`, it checks if `x` is positive.
    - If true, it subtracts `y` from `x` and adds 3 to `y`.
    - If false, it adds 2 to `x` and doubles `y`.
- If `x` is not greater than `y`, it checks if `y` is positive.
    - If true, it subtracts `x` from `y` and doubles `x`.
    - If false, it adds `y` to `x` and increments `y` by 2.
- The function then prints the updated values of `x` and `y`.

#### Result:
- For `checkNumbers(5, 3)`, the output will be:
```
x is positive and greater than y.
After check: x = 2, y = 6
```
- For `checkNumbers(-2, 7)`, the output will be:
```
y is positive and greater than or equal to x.
After check: x = -4, y = 9
```

### 9. Nested `if-else` with logical operations and multiple statements

```cpp
#include <iostream>

int main()
{
    int temperature = 25;
    bool isSunny = true;

    if (temperature > 30)
    {
        if (isSunny)
        {
            std::cout << "It's a hot and sunny day." << std::endl;
            std::cout << "Wear light clothing." << std::endl;
        }
        else
        {
            std::cout << "It's hot but cloudy." << std::endl;
            std::cout << "Consider staying indoors." << std::endl;
        }
    }
    else
    {
        if (isSunny)
        {
            std::cout << "It's a pleasant sunny day." << std::endl;
            std::cout << "Perfect for outdoor activities!" << std::endl;
        }
        else
        {
            std::cout << "It's cool and cloudy." << std::endl;
            std::cout << "Maybe take a jacket with you." << std::endl;
        }
    }

    return 0;
}
```

#### Explanation:
- The code checks the current `temperature` and whether it is `sunny` (`isSunny` is `true` or `false`).
- If the temperature is greater than 30:
    - If it’s sunny, it suggests wearing light clothing.
    - If it’s cloudy, it suggests staying indoors.
- If the temperature is less than or equal to 30:
    - If it’s sunny, it suggests outdoor activities.
    - If it’s cloudy, it suggests taking a jacket for cooler weather.

#### Result:
For `temperature = 25` and `isSunny = true`, the output will be:
```
It's a pleasant sunny day.
Perfect for outdoor activities!
```

---
</details>

## MANDATORY TASK

<details><summary></summary>

### If Statements in C++ - Beginner Level Task for Practicing Conditionals

This task is aimed at providing practice with C++ conditional statements, particularly the `if` statement. The task consists of 14 sub-tasks, each requiring implementation of logic using **only** the `if` keyword.

### Prerequisites

- **Basic Understanding of Flowcharts**: [Flowchart diagrams](https://en.wikipedia.org/wiki/Flowchart) are essential for visualizing the algorithms in the task.
- **C++ Compiler**: Any modern C++ compiler like GCC, Clang, or MSVC.
  
**Note:** Use only the `if` statement in this task. Do not use `else` or `switch`.

**By the end of this task, you should have solid experience using conditional logic and be able to translate flowcharts into working C++ code using only `if` statements.**


---

### Sub-task 1: Implement `doSomething`

**Objective**: Implement the `doSomething` function based on the flowchart below.

![Task 1 Flowchart](images/task1.png)

**Expected Results:**

| `i` Interval     | Expected Result |
|------------------|-----------------|
| (-∞, 0)          | 0               |
| [0, ∞)           | i               |

#### Step-by-Step Guide:

1. **Initialize `result`**  
   Create a variable `result` and assign it the value of `i`.

   ```cpp
   int doSomething(int i) 
   {
       int result = i;
   }
   ```

2. **Add an `if` Condition**  
   Add an `if` statement to check if `result` is less than 0.

   ```cpp
   int doSomething(int i) 
   {
       int result = i;

       if (result < 0) 
       {
           result = 0;
       }
   }
   ```

3. **Return the Result**  
   Return the value of `result`.

   ```cpp
   int doSomething(int i) 
   {
       int result = i;

       if (result < 0) 
       {
           result = 0;
       }

       return result;
   }
   ```

---

### Sub-task 2: Implement `doSomething1`

Follow the flowchart below for this sub-task.

![Task 2 Flowchart](images/task2-1.png)

**Expected Results:**

| `i` Interval     | Expected Result |
|------------------|-----------------|
| (-∞, -5)         | `0 - i * i`     |
| [-5, 0)          | `0 - i`         |
| [0, ∞)           | `i`             |

Implement logic for different intervals of `i` using only `if` statements.

---

### Sub-task 3: Implement `doSomething1` for Booleans

The goal is to return the opposite Boolean value for the input. Follow the flowchart below.

![Task 3 Flowchart](images/task3-1.png)

**Expected Results:**

| `b`    | Expected Result |
|--------|-----------------|
| true   | false           |
| false  | true            |

#### Example:

```cpp
bool doSomething1(bool b) 
{
    if (b) 
    {
        return false;
    }

    return true;
}
```

Alternatively, you could write:

```cpp
return !b;
```

---

### Sub-task 4: Implement `doSomething1` for Two Booleans

In this sub-task, you need to process two Boolean variables according to the flowchart:

![Task 4 Flowchart](images/task4-1.png)

**Expected Results:**

| `b1`   | `b2`   | Expected Result |
|--------|--------|-----------------|
| true   | true   | false           |
| false  | true   | true            |
| true   | false  | true            |
| false  | false  | false           |

Use logical conditions to match the expected outcomes.

---

### Sub-task 5: Implement `doSomething` for Numeric Input

Use the flowchart to handle numeric input conditions.

![Task 5 Flowchart](images/task5-1.png)

**Expected Results:**

| `i`                | Expected Result |
|--------------------|-----------------|
| (-∞, -5)           | `i`             |
| [-5, 0)            | `i + 5`         |
| 0                  | 0               |
| (0, 5]             | `i - 5`         |
| (5, ∞)             | `i`             |

---

### Sub-task 6: Implement `doSomething` for Mathematical Operations

Implement the function to perform different mathematical operations based on the flowchart:

![Task 6 Flowchart](images/task6-1.png)

**Expected Results:**

| `i`                | Expected Result |
|--------------------|-----------------|
| (-∞, -3)           | `i`             |
| [-3, 0)            | `i + (2 * i)`   |
| 0                  | 0               |
| (0, 3]             | `i - (i * i)`   |
| (3, ∞)             | `i`             |

---

### Sub-task 7: Implement `doSomething` for Boolean and Integer Input

Process both Boolean (`b`) and integer (`i`) values according to the flowchart:

![Task 7 Flowchart](images/task7-1.png)

**Expected Results:**

| `b`     | `i`                | Expected Result |
|---------|--------------------|-----------------|
| true    | (-∞, -7]           | `i`             |
| true    | (-7, 7)            | `7 - i`         |
| true    | [7, ∞)             | `i`             |
| false   | (-∞, -5]           | `i + 5`         |
| false   | (-5, 5)            | `i`             |
| false   | [5, ∞)             | `i + 5`         |

---

### Sub-task 8: Implement `doSomething` for Boolean and Integer Input (Complex Case)

Implement a more complex function based on this flowchart:

![Task 8 Flowchart](images/task8.png)

**Expected Results:**

| `b`     | `i`                | Expected Result |
|---------|--------------------|-----------------|
| true    | (-∞, -6)           | true            |
| true    | [-6, -3)           | false           |
| true    | [-3, 0)            | true            |
| true    | 0                  | false           |
| true    | (0, 3]             | true            |
| true    | (3, 6]             | false           |
| true    | (6, ∞)             | true            |
| false   | (-∞, -6)           | true            |
| false   | [-6, -3]           | false           |
| false   | (-3, 0)            | true            |
| false   | 0                  | false           |
| false   | (0, 3)             | true            |
| false   | [3, 6]             | false           |
| false   | (6, ∞)             | true            |

---

### Sub-task 9 to 14: Various Tasks

Each of the remaining sub-tasks (9 to 14) requires following the specific flowcharts provided to implement the `doSomething` function for both numeric and Boolean inputs.

For instance, Sub-task 10 follows the flowchart below:

![Task 10 Flowchart](images/task10.png)

**Expected Results** (example):

| `b1`   | `b2`   | `i`               | Expected Result |
|--------|--------|-------------------|-----------------|
| true   | true   | (-∞, -9)          | `i`             |
| true   | true   | [-9, -2]          | `5 + i`         |
| true   | true   | 0                 | `-1`            |
| false  | true   | (-∞, -10]         | `i + 1`         |
| false  | false  | [5, ∞)            | `i - 1`         |

Follow each corresponding flowchart to build the conditional logic.

---

### Additional Resources

- [The `if` Statement in C++](https://cplusplus.com/doc/tutorial/control/)
- [The `return` Statement](https://cplusplus.com/doc/tutorial/functions2/)
- [Logical Operators](https://cplusplus.com/doc/tutorial/operators/#logical)
</details>