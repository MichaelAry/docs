#include <iostream>
#include <iomanip>

int main (){
/*    //умножаем n на все числа до m
    int n;
    std::cin>>n;
    std::cout<<std::endl;
    for (int i=1;i<=n;i++){
        for (int j=1;j<=n;j++){
        std::cout <<std::setw(2)<<i*j<<", ";
        }
        std::cout<<std::endl;
    }
*/

int a,b,counter;
counter=0;
for (;;){
std::cin>>a>>b;
std::cout<<std::endl;
std::cout<<a<<"*"<<b<<"="<<"?";
std::cout<<std::endl;
a*=b;
std::cin>>b;
std::cout<<std::endl;
if (a==b){std::cout<<"True";std::cout<<std::endl;}
else {std::cout<<"False";std::cout<<std::endl;}
counter++;
std::cout<<counter<<" attempts"<<std::endl;
}
return 0;
}