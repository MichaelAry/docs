#include <iostream>
#include<cmath>
#include<cstring>
#include "OperationsWithArrays.h"


//#include "ConsoleApplication26.h"

const int limit = 10;
const int left = 6;
const int right = 5;
//int intNumber(int left, int right);
int n{OperationsWithArrays::initNumber(a,b)};
void inputArray( int  integer[], int n);
void outputArray(int a[], int n);
void reverse(int a[], int n);
void swap(int& a, int& b);

int main()
{
  int a{ 5 }, b{ 7 };
  int& ra = a;
   
  int integer[limit]{ 0, 1, 6 };
  int n{ intNumber(left, right) };
  inputArray( integer, n);
  outputArray(integer, n);
  reverse(integer, n);
  for (int i = 0; i < n; i++) {
    std::cout << integer[i] << (i != n - 1 ? ", " : ". ");
  }
}

// Function to input elements into the array
void inputArray(int  integer[], int n)
{
  std::cout << "Enter elements of array:" << std::endl;
  for (int i = 0; i < n; i++) {
    std::cout << "integer[" << (i + 1) << "]";
    std::cin >> integer[i];
  }
}

// Function to get a valid number from the user within specified bounds
int OperationsWithArrays::initNumber( int left, int right)
{
  if (left > right) {
    swap(left, right);
  }
  int n{ 0 };
  while (true) {
    std::cout << "Enter n (" << left<<"..."<<right << "):";
    std::cin >> n;
    if (n >= left && n <= right) {
      break;
    }
    std::cout << "Invalid ot 1 do " << right;
    system("pause");
    system("cls");
  }
  return n;
}

// Function to output the elements of the array
void outputArray(int a[], int n) {

}

// Function to reverse the elements of the array
void reverse(int a[], int n) {
  for (int i = 0; i < n / 2; i++) {
    swap(a[i], a[n - i - 1]);
    /*int tmp = a[i];
    a[i] = a[n - i - 1];
    a[n - i - 1] = tmp;*/
  }
}

// Function to swap two integers
void swap(int& a, int& b) {
  int tmp = a;
  a = b;
  b = tmp;
}