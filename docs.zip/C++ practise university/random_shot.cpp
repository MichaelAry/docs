#include <iostream>
#include <ctime>
#include <cmath>
using namespace std;
/*
-10 10                 10 10                    10 10



0 -10                 0 0                   10 0



-10 -10                0 -10                   10 10
роспись координат мишени
*/
int main(){
    srand(time(NULL));
    int score{0}, iteration{0},x1,y1,c0{0},c1{2},c2{5}, c3{10};
    do{
        int x=rand()%20;
        x-=10;
        int y=rand()%20;
        y-=10;
        if((x==c0) &&(y==c0)){
            score+=100;
            cout<<"x= "<<x<<endl;
            cout<<"y= "<<y<<endl;
            cout<<"попали в 100"<<endl;
        }
        else if ((x*x+y*y)<=c1*c1){
            cout<<"x= "<<x<<endl;
            cout<<"y= "<<y<<endl;            
            score+=20;
            cout<<"попали в 20"<<endl;
        }
        else if ((x*x+y*y)<=c2*c2){
            cout<<"x= "<<x<<endl;
            cout<<"y= "<<y<<endl;            
            score+=10;
            cout<<"попали в 10"<<endl;
        }
        else if ((x*x+y*y)<=c3*c3){
            cout<<"x= "<<x<<endl;
            cout<<"y= "<<y<<endl;
            score+=5;
            cout<<"попали в 5"<<endl;
        }
        else if ((x*x+y*y)>c3*c3){
        cout<<"x= "<<x<<endl;
        cout<<"y= "<<y<<endl;
        cout<<"не попали"<<endl;}
        iteration++;
    }
    while (score<=100);
    cout<<"ход "<<iteration<<endl;
    cout<<"ваш счет"<<score<<endl;
    return 0;
}