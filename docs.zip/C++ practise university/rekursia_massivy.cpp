#include <iostream>
#include <cmath>
#define ull unsigned long long


ull getFactDigits(unsigned int n){
    return 1+(int)((n+0.5)*log10(n)-0.43*n+0.4);
}

ull fact(unsigned int n){
    if (n>1){
        return n*fact(n-1);
    }
    else {return 1;}
}

unsigned int getArrLength(unsigned int n){
    double digits{0};

    for (int i=0;i<n;i++){
        digits+=log10(i);
    }
    return digits;
}



int main(){
    unsigned int n;
    std::cin>>n; std::cout<<std::endl;
    ull res=getArrLength(n);
    std::cout<<res<<std::endl;
    res=getFactDigits(n);
    std::cout<<res;
    return 0;
}



