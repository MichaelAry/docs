#include <iostream>
#include <cmath>

int find_h(int a, int b){
    return pow(a*a+b*b, 1./2);
}

void print (int a){
    std::cout<<a<<std::endl;
}

int main(){
    int a,b,c;
    std::cin>>a>>b>>c;
    print (find_h(find_h(a,b),c));
    return 0;
}