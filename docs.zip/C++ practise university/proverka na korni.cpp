#include <iostream>

int main() 
{
    float a,b,c;
    std::cin>>a;std::cout<<std::endl;
    std::cin>>b;std::cout<<std::endl;
    std::cin>>c;std::cout<<std::endl;
    if(a==0){std::cout<< "Mistake"<<std::endl;return 0;} 
    if (b*b-4*a*c<0){std::cout<<"No roots";std::cout<< std::endl;}
    else {std::cout<<"Roots exist";std::cout<< std::endl;}
    return 0;
}