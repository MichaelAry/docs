#include <iostream>
#include <cstring>
using namespace std;
int n,m;
string res{""};
int base{16};
int main(){
    cin>>n;cout<<endl;
    for (m=n%16;n/16;){
        if (m<10){
        res+=(char)m;
    }
    else {switch(m){
        case 10: res+="A";
        break;
        case 11: res+="B";
        break;
        case 12: res+="C";
        break;
        case 13: res+="D";
        break;
        case 14: res+="E";
        break;
        case 15: res+="F";
        }
    }
    }
    cout<<res;
    return 0;
}