#include <iostream>
#include <cmath>

int main(){
    float sinx=0, x;
    int n,j=1, fact=1;
    std::cin>>n>>x; std::cout<<std::endl;
    for (int i=0;i<n;i++){
        for(int j=0;j<2*n+1;j++){
            fact*=j;
        }
        sinx+=(pow(-1,i)*pow(x,2*i+1)/(2*i+1))/(fact);
    }
    std::cout<<sinx;
    return 0;
}