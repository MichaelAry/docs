#include <iostream>
/*int main(){
    int border_val{0};
    int count{0};
    while (true){
        std::cin>>count;
        if (count>0){
            break;
        }        
    }
    while (true){
        std::cin>>border_val;
        if (border_val>0){
            break;
        }        
    }
    for (int i=1; i<=count; i++){
        if ((i%3==0)&&(i%5==0)){std::cout<<"fizzbuzz"<<" ";}
        else if (i%3==0){std::cout<<"fizz"<<" ";}
        else if (i%5==0){std::cout<<"buzz"<<" ";}
        else {std::cout<<i<<" ";}
        if (i%border_val==0){std::cout<<std::endl;}
    }  
return 0;
}
*/



int inputValue(std::string message);
std::string createValue(int i, int k, int l, std::string fizz, std::string buzz);
std::string createMessage(int i, int k, int l, std::string fizz, std::string buzz);
std::string createSeparator(int n, int count, int border, std::string separatorBetween, std::string separatorNewLine, std::string separatorEnd);
std::string inputString(std::string message);

int main(){
    char ok{'y'};
    do{
    std::string fizz="fizz";
    std::string buzz="buzz";
    std::string chunk{""};
    int k=3;
    int l=5;
    int borderValue{inputValue("border: ")};
    int count {inputValue("count: ")};
    std::string separatorBetween=", ", separatorNewLine="\n", separatorEnd=". ";
    for (int i=1; i<=borderValue; i++){
        std::string message{createMessage(i,k,l,fizz,buzz)};
        std::string separator{createSeparator(i,count, borderValue, separatorBetween, separatorEnd, separatorNewLine)};
        chunk+=message+separator;
    }
    std::cout<<chunk;
    std::cout<<std::endl;
    std::cout<<"wanna continue?";
    std::cin>>ok;
    }
    while((ok=='y')||(ok=='Y'));
    return 0;
}


int inputValue(std::string message){
    int value{0};
    while(true){
        std::cin>>value;
        if (value>0){
            return value;
        }
    }
}

std::string createMessage(int i, int k, int l, std::string fizz, std::string buzz){
    std::string temp("");
    if ((!(i%k))&&(!(i%l))){
        temp=fizz+buzz;}
    else if (!(i%k)){
        temp=fizz;
    }
    else if (!(i%l)){
        temp=buzz;
    }
    else{
        temp=std::to_string(i);
    }
    return temp;
}

std::string createSeparator(int i, int count, int border, std::string separatorBetween, std::string separatorNewLine, std::string separatorEnd){
    std::string temp{""};
    if (i==count){
        temp=separatorEnd;
    }
    else if (!(i%count)){
        temp=separatorBetween+separatorNewLine;
    }
    else{
        temp=separatorBetween;
    }
    return temp;
}


/*std::string inputString(std::string message){
    std::string temp{""};

}
*/