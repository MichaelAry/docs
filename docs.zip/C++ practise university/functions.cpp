#include <iostream>

int mult(int a, int b){
    return a*b;
}

void print (int a){
    std::cout<<a<<std::endl;
}

int main(){
    int a,b;
    std::cin>>a>>b;
    int c=mult(a,b);
    print(c);
    print(mult(a,b));
    return 0;
}