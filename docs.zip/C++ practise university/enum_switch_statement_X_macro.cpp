#include <iostream>

/*int main (){
    int month;
    std::cin>>month;
    switch (month){
        case 1:{std::cout<<"Mezim";}break;
        case 2:{std::cout<<"Pancakes";}break;
        case 3:{std::cout<<"Rafael";}break;
        case 4:{std::cout<<"Hochu Pizzu";}break;
        case 5:{std::cout<<"Shashlychki";}break;
        case 6:{std::cout<<"CHera";}break;
        case 7:{std::cout<<"morozhenoe";}break;
        case 8:{std::cout<<"coffe";}break;
        case 9:{std::cout<<"glintvein";}break;
        case 10:{std::cout<<"arbuz";}break;
        case 11:{std::cout<<"chai";}break;
        case 12:{std::cout<<"mandariny";}break;
        default: std::cout<<"нет такого месяца"; //universal else
    }
}
*/


//get the day of the week by its number and know if it's workday

#include <iostream>
// switch, enum and X macro

#define WEEK_DAYS \
X(MON, "Monday", true) \
X(TUE, "Tuesday", true) \
X(WED, "Wednesday", true) \
X(THU, "Thursday", true) \
X(FRI, "Friday", true) \
X(SAT, "Saturday", false) \
X(SUN, "Sunday", false)

#define X(day, name, workday) day,
enum WeekDay : unsigned int
{
    WEEK_DAYS
};
#undef X

#define X(day, name, workday) name,
char const *weekday_name[] =
{
    WEEK_DAYS
};
#undef X

#define X(day, name, workday) workday,
bool weekday_workday[]
{
    WEEK_DAYS
};
#undef X

int main()
{
    int day;
    WeekDay wd;
    std::cin>>day;
    day--; // чтобы нумерация шла не с 0, а с 1
    switch (day){   
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:{std::cout<<"Enum valuse "<<(WeekDay)day<<" Name string "<<weekday_name[(WeekDay)day]<<" Work day "<<weekday_workday[(WeekDay)day]<<std::endl;}break;
    default: std::cout<<"net takogo dnya"<<std::endl;
    }

/*    std::cout << "Enum value: " << WeekDay::THU << std::endl;
    std::cout << "Name string: " << weekday_name[WeekDay::THU] << std::endl;
    std::cout << std::boolalpha << "Work day: " << weekday_workday[WeekDay::THU] << std::endl;

    WeekDay wd = SUN;
    std::cout << "Enum value: " << wd << std::endl;
    std::cout << "Name string: " << weekday_name[wd] << std::endl;
    std::cout << std::boolalpha << "Work day: " << weekday_workday[wd] << std::endl;
*/
    return 0;
}
