#include <iostream>

int main (){
    int a1,a2,a3,b1,b2,b3;
    std::cin>>a1>>a2>>a3>>b1>>b2>>b3;
    if ((a1<=b1)&&(a2<=b2)&&(a3<=b3)){std::cout<<"Nice";std::cout<<std::endl;}
        else if ((a2<=b1)&&(a3<=b2)&&(a1<=b3)){std::cout<<"Nice";std::cout<<std::endl;}
            else if ((a3<=b1)&&(a1<=b2)&&(a2<=b3)){std::cout<<"Nice";std::cout<<std::endl;}
                else {std::cout<<"Not nice";}
return 0;
}
//доработать через switch