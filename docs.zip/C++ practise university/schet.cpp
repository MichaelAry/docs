#include <iostream>
#include <cmath>

int main(){
    int x=2,next;
    float c=0;
    int n;
    std::cin>>n;std::cout<<std::endl;
    for (int i=0;i<n;i++){
        c=c+pow(x,2*i+1)/(2*i+1);
    std::cout<<c<<std::endl;;
    }
    return 0;
}