#include <iostream>
#include <cmath>

int find_h(int a, int b){
    return pow(a*a+b*b, 1./2);
}

void print (int a){
    std::cout<<a<<std::endl;
}

int main(){
    float x1,y1,x2,y2,x3,y3,x4,y4;
    std::cin>>x1>>y1>>x2>>y2>>x3>>y3>>x4>>y4;
    float a =find_h(x2-x1,y2-y1);
    float b =find_h(x3-x2,y3-y2);
    float c =find_h(x4-x3,y4-y3);
    float v =find_h(find_h(a,b),c);
    print (c);
    return 0;
}