#include <iostream>

int find_h(int a, int b){
    return pow(a*a+b*b, 1./2);
}

void print (float a){
    std::cout<<a<<std::endl;
}

findSide(char leg1, char leg2, char h){
    int counter{0};
    if(leg1=="x"){counter+=1;} 
    if(leg2=="x"){counter+=1;}
    if(h=="x"){counter+=1;}
    if (count!=1){std::cout<<"nonono";}
    else if (leg1=="x"){
        leg1=float(h)*float(h)*float(leg2)*float(leg2);
        return leg1;
    }
    else if (leg2=="x"){
        leg2=float(h)*float(h)*float(leg1)*float(leg1);
        return leg2;
    }
    else if (h=="x"){
        h=pow(float(leg1)*float(leg1)float(leg2)*float(leg2),1./2);
        return h;
    }
}

int main(){
    char leg1, leg2, h;
    std::cin>>leg1>>leg2>>h;
    print ()
    return 0;
}