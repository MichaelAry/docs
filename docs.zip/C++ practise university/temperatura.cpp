#include <iostream>
#include <clocale>
int main(){
    setlocale (LC_ALL,"Russian"); //RUS, 0 - язык системы о умолчанию
    float c;
    std::cin>>c;
    std::cout<<std::endl;
    std::cout<<c*1.8+32;
    std::cout<<std::endl;
    std::cout<<c-273.15;
    std::cout<<std::endl;
}
