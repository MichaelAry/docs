#include <iostream>

int main (){
    double f0=0,f1=1,s,n;
    std::cin>>n;    std::cout<<std::endl;   
    for (int i=0; i<n;i++){
        if (n==1)
            std::cout<<f0<<std::endl;
        if (n==2)
            std::cout<<f1<<std::endl;
        s=f0+f1;
        f0=f1;
        f1=s;
    }
    std::cout<<f0;
    return 0;
}