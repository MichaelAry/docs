#include <iostream>
#include <ctime>

const int length=3;

void createAr(short ar[], unsigned short length){
    for (int i=0; i<length; i++){
        ar[i]=short(std::rand()%10);
    }
}

void printAr(short ar[length][2*length], unsigned short length, bool format){
    if (format){std::cout<<" ";}
    for (int i=0; i<length; i++){
        std::cout<<ar[i][j];
    }
    std::cout<<std::endl;
}


void sum(short ar1[], short ar2[], short ar3[], unsigned short length, bool& format){
    for (int i=length; i>=0; i--){
        ar3[i+1]+=ar1[i]+ar2[i];
        if (ar3[i+1]>=10){
            ar3[i+1]=ar3[i+1]-10;
            ar3[i]+=1;
        }
    }
    if (ar1[0]+ar2[0>=10]){
        format=1;
    }
}

void mult(short ar1[], short ar2[], short ar3[], unsigned short length, bool& format){
    short matr[length][2*length]{0};
    short add[2*length];
    for (int j=0; j<length; j++){
        for (int i=2*length-1;i>=0;i--){
            matr[j][i]+=((ar1[i]*ar2[i])%10);
            matr[j][i-1]+=(ar1[i]*ar2[i])/10;
            add[i]=matr[j][i];
            sum(ar3, ar2, ar3, 2*length);
        }
    }
    
}

int main(){
    srand(time(NULL));
    bool format{1};

    short ar1[length]{0};
    short ar2[length]{0};
    short ar3[length+1]{0};
    short matrix[length][2*length]{0};

    createAr(ar1, length);
    createAr(ar2, length);
    sum(ar1, ar2, ar3, length-1, format);
    
    printAr(ar1, length, format);
    printAr(ar2, length, format);
   /* if (ar3[0]==0){
        std::cout<<" "; 
        for (int i=1; i<length+1; i++){
        std::cout<<ar3[i];
    }
    }
    else {printAr(ar3, length+1, 0);}*/
    mult (ar1, ar2, ar3, length);
    printAr(matrix, length);


    return 0;
}
