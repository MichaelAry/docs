#include <iostream>

/*int main(){
    int a1x,a2x,a1y,a2y,b1x,b2x,b1y,b2y, x1,y1,x2,y2;
    std::cin>>a1x>>a1y>>a2x>>a2y>>b1x>>b1y>>b2x>>b2y;
    if (a1x<=b1x){x1=a1x;}
    else {x1=b1x;}
    if (a1y<=b1y){y1=a1y;}
    else {y1=b1y;}
    if (a2x>=b2x){x2=a2x;}
    else {x2=b2x;}
    if (a2y>=b2y){y2=a2y;}
    else {y2=b2y;}
    std::cout<<"кордината первая: "<<x1<<";"<<y1<<std::endl;
    std::cout<<"кордината вторая: "<<x2<<";"<<y2<<std::endl;
    return 0;
} некрасиво и сложно, естть вариант написать проще
*/



/*int main(){
    int a1x=1,a2x=2,a1y=2,a2y=4,b1x=2,b2x=4,b1y=1,b2y=2, x1,y1,x2,y2;
//    std::cin>>a1x>>a1y>>a2x>>a2y>>b1x>>b1y>>b2x>>b2y;
    a1x<=b1x ? x1=a1x : x1=b1x;
    a1y<=b1y ? y1=a1y : y1=b1y;
    a2x>=b2x ? x2=a2x : x2=b2x;
    a2y>=b2y ? y2=a2y : y2=b2y;

    std::cout<<"кордината первая: "<<x1<<";"<<y1<<std::endl;
    std::cout<<"кордината вторая: "<<x2<<";"<<y2<<std::endl;
    return 0;
} */


/*int main(){
    int a1x=1,a2x=2,a1y=2,a2y=4,b1x=2,b2x=4,b1y=1,b2y=2;
//    std::cin>>a1x>>a1y>>a2x>>a2y>>b1x>>b1y>>b2x>>b2y;
    int x1 = a1x<=b1x ? x1=a1x : x1=b1x;
    int y1 = a1y<=b1y ? y1=a1y : y1=b1y;
    int x2 = a2x>=b2x ? x2=a2x : x2=b2x;
    int y2 = a2y>=b2y ? y2=a2y : y2=b2y;

    std::cout<<"кордината первая: "<<x1<<";"<<y1<<std::endl;
    std::cout<<"кордината вторая: "<<x2<<";"<<y2<<std::endl;
    return 0;
} */

int getCoordBiggest (int f, int s){
    return f<=s ? f : s;
}

int getCoordSmallest (int f, int s){
    return f>=s ? f : s;
}

int main(){
    int a1x=1,a2x=2,a1y=2,a2y=4,b1x=2,b2x=4,b1y=1,b2y=2;
//    std::cin>>a1x>>a1y>>a2x>>a2y>>b1x>>b1y>>b2x>>b2y;
    int x1 = getCoordBiggest(a1x,b1x);
    int y1 = getCoordBiggest(a1y,b1y);
    int x2 = getCoordSmallest(a2x,b2x);
    int y2 = getCoordSmallest(a2y,b2y);

    std::cout<<"кордината первая: "<<x1<<";"<<y1<<std::endl;
    std::cout<<"кордината вторая: "<<x2<<";"<<y2<<std::endl;
    return 0;
}


//f>=s ? f : s; где ? -- это then из Паскаля, а : --  else