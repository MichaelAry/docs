#include <iostream>
using namespace std; 
int enterF (int ch);


int main(){
    int ch;
    int checker{0};
    ch=enterF(ch);
    cout<<endl;
    for (int i=1;i<ch;i++){
        for (int j=1; j<ch;j++){
            if (i*i+j*j==ch){
                cout<<ch<<"="<<i<<"*"<<i<<"+"<<j<<"*"<<j<<endl;
                i+=(ch+1);
                checker+=1;
            }
        }
    }
    if (checker==0){
        cout<<"Невозможно представить число в виде суммы двух квадратов";
    }
    return 0;
}

int enterF(int ch){
    while (1){
        cout<<"enter the number from 1 to +eternity"<<endl;
        cin>>ch;
        if (ch>0){
            break;
        }
    }
    return ch;
}
