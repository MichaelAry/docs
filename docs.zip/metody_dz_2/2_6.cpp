#include <iostream>
using namespace std;

int god(int g);

int main(){
    float s{100};//количество гектаров
    float u{20};//урожайность
    int g;//год
    g=god(g);cout<<endl;
    for (int i=0;i<g;i++){
        s=s*1.05;
        u=u*1.02;
    }
    cout<<"к "<<g<<" году:"<<endl;;
    cout<<"площадь "<<s<<endl;
    cout<<"урожайность "<<u;
    return 0;
}

int god(int g){
    while (1){
        cout<<"enter the year from 1 to +eternity"<<endl;
        cin>>g;
        if (g>0){
            break;
        }
    }
    return g;
}